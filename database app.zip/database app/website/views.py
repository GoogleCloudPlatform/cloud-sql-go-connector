
from flask import Blueprint, app, redirect, render_template, request, jsonify, url_for, send_file
from flask_login import login_required, current_user
from website import models
from .models import User, File
from . import db
import json
import os
import csv
import pandas as pd

views = Blueprint('views',__name__)



@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    if request.method == 'POST':
        file = request.files['file']
        #uploads csv file to website directory folder 
        filepath = "website/static/csvfiles" + file.filename
        file.save(filepath)
        db.session.add(file)
        db.session.commit()
        return redirect(url_for('views.analysis'))
        
    return render_template("home.html",user=current_user)


@views.route('/analysedata', methods=['POST'])
def analysis():

 return render_template("analysis.html")




@views.route('/delete-file', methods=['POST'])
def delete_file():
    file = json.loads(request.data)
    fileId = file['fileId']
    file = File.query.get(fileId)
    if file:
        if file.user_id == current_user.id:
            db.session.delete(file)
            db.session.commit()
            
    return jsonify({})